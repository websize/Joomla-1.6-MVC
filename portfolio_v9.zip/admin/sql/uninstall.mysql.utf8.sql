# table portfolio

DROP TABLE IF EXISTS `#__portfolio`;
 
#table portfolio_technics

DROP TABLE IF EXISTS `#__portfolio_technics`;